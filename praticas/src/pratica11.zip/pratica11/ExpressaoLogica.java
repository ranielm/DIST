package pratica11;

public interface ExpressaoLogica{
	public boolean operacao();
}
