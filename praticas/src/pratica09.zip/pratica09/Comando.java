package pratica09;

public interface Comando {
    public void executar();
    public void undo();
}
