package pratica09;

public class PanelaEletrica {
    public void ligar(){
        System.out.println("Panela Elétrica ON");
    }
    
    public void desligar(){
        System.out.println("Panela Elétrica OFF");
    }
}