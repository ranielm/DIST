package pratica09;

public class ComandoNenhum implements Comando{
    public void executar() {    
    }
    public void undo() {    
    }
}
