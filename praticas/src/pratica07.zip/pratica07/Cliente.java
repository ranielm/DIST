/* @author Raniel Mendonça - 11321BCC024 e Amanda Souza - 11421BCC036 */

package pratica7;

import java.util.Scanner;

public class Cliente {

	private FabricaDeCadeias c1;

	public Cliente() {
		// inicializa a cadeia
		this.c1 = new Distribuir100();
		FabricaDeCadeias c2 = new Distribuir50();
		FabricaDeCadeias c3 = new Distribuir20();
        FabricaDeCadeias c4 = new Distribuir10();
        FabricaDeCadeias c5 = new Distribuir05();
		FabricaDeCadeias c6 = new Distribuir02();
        FabricaDeCadeias c7 = new Distribuir01();
                
        // seta a cadeia de responsabilidades
        
		c1.setNextChain(c2);
		c2.setNextChain(c3);
        c3.setNextChain(c4);
        c4.setNextChain(c5);
        c5.setNextChain(c6);
        c6.setNextChain(c7);
	}

	public static void main(String[] args) {
		Cliente atmDispenser = new Cliente();
		while (true) {
			int amount = 0;
			System.out.println("Enter amount to dispense");
			Scanner input = new Scanner(System.in);
			amount = input.nextInt();
			/*if (amount % 10 != 0) {
				System.out.println("Amount should be in multiple of 10s.");
				return;
			}*/
			// process the request
			atmDispenser.c1.dispense(new MoedaCorrente(amount));
		}

	}
}