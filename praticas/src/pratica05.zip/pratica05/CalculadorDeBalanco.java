package pratica05;

import java.util.Calendar;

public class CalculadorDeBalanco {
	
	// atributos e campos omitidos.
	public double calcularBalanco(Integer conta, Calendar calendar) {
	// lógica omitida
		return conta;
	}
	
}