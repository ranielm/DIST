package pratica05;

public interface Dinheiro {

	static Dinheiro valorDe(double calcularBalanco, Object moeda) {
		// valor do balanço na moeda selecionada
		return null;
	}

}
