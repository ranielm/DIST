package pratica05;

public class Conta {

	public Integer getId() {
		// TODO Auto-generated method stub
		return 1526;
	}

}