package pratica05;

import java.util.Date;

public interface ResolverBalanco {

	public Dinheiro balancoPara(Conta conta, Date data);

}