package pratica08;

/**
 *
 * @author raniel
 */
public interface Pedido 
{
    public double getPreco();
    public String getDescricao();
}