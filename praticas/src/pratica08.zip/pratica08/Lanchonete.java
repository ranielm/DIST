package pratica08;

public interface Lanchonete {

	void fazerPedido();
}