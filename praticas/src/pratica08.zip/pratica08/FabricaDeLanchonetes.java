package pratica08;

public interface FabricaDeLanchonetes {

    Lanchonete criarLanchonete();

}