/* @author Raniel Mendonça - 11321BCC024 e Amanda Souza - 11421BCC036 */

package pratica12;

public class Cliente {
	public static void main(String[] args) {
		Mario mario = new Mario();
		mario.pegarCogumelo();
		mario.pegarPena();
		mario.levarDano();
		mario.pegarFlor();
		mario.pegarFlor();
		mario.levarDano();
		mario.levarDano();
		mario.pegarPena();
		mario.levarDano();
		mario.levarDano();
		mario.levarDano();
	}
}