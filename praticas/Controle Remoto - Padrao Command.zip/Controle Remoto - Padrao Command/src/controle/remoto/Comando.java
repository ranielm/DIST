package controle.remoto;

public interface Comando {
    public void executar();
    public void undo();
}
