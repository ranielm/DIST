package controle.remoto;

public class ComandoNenhum implements Comando{
    public void executar() {    
    }
    public void undo() {    
    }
}
